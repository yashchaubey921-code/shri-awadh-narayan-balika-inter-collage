import React, { useState, useEffect } from 'react';

function App() {
  const [deferredPrompt, setDeferredPrompt] = useState(null);
  const [isInstallable, setIsInstallable] = useState(false);

  useEffect(() => {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    });
  }, []);

  const handleInstallClick = () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      deferredPrompt.userChoice.then((choiceResult) => {
        if (choiceResult.outcome === 'accepted') {
          console.log('User accepted the install prompt');
        }
        setDeferredPrompt(null);
        setIsInstallable(false);
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 font-sans">
      {/* Header */}
      <header className="bg-blue-900 text-white shadow-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-xl font-bold">Sanss Academy</h1>
            <p className="text-xs text-blue-200">Shri Awadh Narayan Balika Inter College</p>
          </div>
          {isInstallable && (
            <button 
              onClick={handleInstallClick}
              className="bg-yellow-500 hover:bg-yellow-600 text-blue-950 font-bold px-4 py-2 rounded-lg text-sm transition shadow"
            >
              Install App 📱
            </button>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-800 to-indigo-900 text-white py-16 px-4 text-center">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-extrabold mb-4">Welcome to Shri Awadh Narayan Balika Inter College</h2>
          <p className="text-lg text-blue-100 mb-6">Empowering young minds with quality education, discipline, and bright futures.</p>
          <a href="#notice" className="bg-white text-blue-900 font-semibold px-6 py-3 rounded-full shadow hover:bg-blue-50 transition">
            Check Latest Notices
          </a>
        </div>
      </section>

      {/* Main Content Sections */}
      <main className="max-w-7xl mx-auto px-4 py-10 space-y-12">
        
        {/* Notice Board */}
        <section id="notice" className="bg-white p-6 rounded-xl shadow-md border-l-4 border-blue-600">
          <h3 className="text-2xl font-bold text-blue-900 mb-4">📢 Notice Board / Announcements</h3>
          <ul className="space-y-3 text-gray-700">
            <li className="p-3 bg-blue-50 rounded-lg flex justify-between items-center">
              <span>Admissions open for the new academic session. Register now!</span>
              <span className="text-xs bg-blue-200 text-blue-800 px-2 py-1 rounded">New</span>
            </li>
            <li className="p-3 bg-gray-50 rounded-lg">
              <span>Upcoming Unit Test schedules have been updated on the portal.</span>
            </li>
          </ul>
        </section>

        {/* About Section */}
        <section className="bg-white p-6 rounded-xl shadow-md">
          <h3 className="text-2xl font-bold text-blue-900 mb-4">🏫 About Our Institution</h3>
          <p className="text-gray-600 leading-relaxed">
            Shri Awadh Narayan Balika Inter College (Sanss Academy) is dedicated to fostering academic excellence, moral values, and all-round development for students. Our experienced faculty and well-equipped campus ensure a nurturing environment for every student.
          </p>
        </section>

      </main>

      {/* Footer */}
      <footer className="bg-blue-950 text-white text-center py-6 mt-12">
        <p className="text-sm">© {new Date().getFullYear()} Shri Awadh Narayan Balika Inter College. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default App;