self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.useCache ? Promise.resolve() : Promise.resolve()
  );
});

self.addEventListener('fetch', (e) => {
  e.respondWith(
    caches.match(e.request).then((response) => response || fetch(e.request))
  );
});